"""Recursive-descent/Pratt parser for the supported Luau subset.

Runtime type annotations, aliases and attributes are parsed and erased. Parser
errors are intentionally explicit; unsupported syntax is rejected instead of
silently emitted as incorrect bytecode.
"""
from __future__ import annotations
from typing import Optional
from ast_nodes import *
from tokens import Token, Tokenizer, TokenizeError, tokenize


class ParseError(SyntaxError):
    pass


BIN_PREC = {
    "or": (1, 1), "and": (2, 2),
    "<": (3, 3), ">": (3, 3), "<=": (3, 3), ">=": (3, 3), "~=": (3, 3), "==": (3, 3),
    "|": (4, 4), "~": (5, 5), "&": (6, 6), "<<": (7, 7), ">>": (7, 7),
    "..": (8, 7),
    "+": (9, 9), "-": (9, 9),
    "*": (10, 10), "/": (10, 10), "//": (10, 10), "%": (10, 10),
    "^": (12, 11),
}
UNARY = {"not", "-", "#", "~"}
COMPOUND = {"+=", "-=", "*=", "/=", "//=", "%=", "^=", "..="}
BLOCK_END = {"end", "else", "elseif", "until", "<eof>"}


class Parser:
    def __init__(self, source: str, _tokens: Optional[list[Token]] = None):
        self.source = source
        self.tokens = _tokens or tokenize(source)
        self.i = 0

    @property
    def tok(self) -> Token:
        return self.tokens[min(self.i, len(self.tokens) - 1)]

    def peek(self, n: int = 1) -> Token:
        return self.tokens[min(self.i + n, len(self.tokens) - 1)]

    def at(self, value: object) -> bool:
        return self.tok.value == value

    def match(self, value: object) -> bool:
        if self.at(value): self.i += 1; return True
        return False

    def expect(self, value: object) -> Token:
        if not self.at(value): self.error(f"expected {value!r}, got {self.tok.value!r}")
        token = self.tok; self.i += 1; return token

    def expect_name(self) -> str:
        if self.tok.kind != "NAME": self.error(f"expected identifier, got {self.tok.value!r}")
        value = str(self.tok.value); self.i += 1; return value

    def error(self, message: str) -> None:
        t = self.tok
        raise ParseError(f"{message} at line {t.line}, column {t.column}")

    def parse(self) -> Chunk:
        body = self.parse_block({"<eof>"})
        self.expect("<eof>")
        return Chunk(body)

    def parse_block(self, stops: set[str]) -> list[Node]:
        body: list[Node] = []
        while not (isinstance(self.tok.value, str) and self.tok.value in stops) and self.tok.kind != "EOF":
            if self.match(";"): continue
            before = self.i
            body.append(self.parse_statement())
            self.match(";")
            if self.i == before: self.error("parser made no progress")
        return body

    def _skip_balanced(self, opening: str, closing: str) -> None:
        self.expect(opening); depth = 1
        while depth:
            if self.tok.kind == "EOF": self.error(f"unfinished {opening}{closing} group")
            if self.match(opening): depth += 1
            elif self.match(closing): depth -= 1
            else: self.i += 1

    def _skip_attributes(self) -> None:
        while self.match("@"):
            if self.match("["):
                # Luau attribute list, e.g. @[native, deprecated].
                depth = 1
                while depth:
                    if self.tok.kind == "EOF": self.error("unfinished attribute list")
                    if self.match("["): depth += 1
                    elif self.match("]"): depth -= 1
                    else: self.i += 1
            else:
                self.expect_name()
                if self.at("("):
                    self._skip_balanced("(", ")")
                elif self.at("{"):
                    self._skip_balanced("{", "}")

    def parse_statement(self) -> Node:
        self._skip_attributes()
        if self.match(";"): return Noop()
        if self.match("local"):
            if self.match("function"):
                name = self.expect_name()
                fn = self.parse_function_body()
                return FunctionDef(Name(name), fn, local=True)
            is_const = self.match("const")
            names = self.parse_bindings()
            values = self.parse_exprlist() if self.match("=") else []
            return Local(names, values, is_const)
        if self.at("const") and self.peek().value == "function":
            self.i += 2
            name = self.expect_name()
            return FunctionDef(Name(name), self.parse_function_body(), local=True)
        if self.at("const") and self.peek().kind == "NAME" and self.peek().value != "function":
            self.i += 1
            names = self.parse_bindings()
            self.expect("=")
            return Local(names, self.parse_exprlist(), const=True)
        if self.match("function"):
            target: Node = Name(self.expect_name())
            while self.match("."):
                target = Index(target, Literal(self.expect_name()))
            method = None
            if self.match(":"):
                method = self.expect_name()
                target = Index(target, Literal(method))
            fn = self.parse_function_body()
            if method is not None:
                fn.params.insert(0, "self")
            return FunctionDef(target, fn)
        if self.match("if"):
            clauses: list[tuple[Node, Block]] = []
            cond = self.parse_expr(); self.expect("then")
            clauses.append((cond, Block(self.parse_block({"elseif", "else", "end"}))))
            while self.match("elseif"):
                cond = self.parse_expr(); self.expect("then")
                clauses.append((cond, Block(self.parse_block({"elseif", "else", "end"}))))
            other = None
            if self.match("else"):
                other = Block(self.parse_block({"end"}))
            self.expect("end")
            return If(clauses, other)
        if self.match("while"):
            cond = self.parse_expr(); self.expect("do")
            body = Block(self.parse_block({"end"})); self.expect("end")
            return While(cond, body)
        if self.match("repeat"):
            body = Block(self.parse_block({"until"})); self.expect("until")
            return Repeat(body, self.parse_expr())
        if self.match("for"):
            names = self.parse_bindings()
            if self.match("="):
                start = self.parse_expr(); self.expect(","); limit = self.parse_expr()
                step = self.parse_expr() if self.match(",") else Literal(1)
                self.expect("do"); body = Block(self.parse_block({"end"})); self.expect("end")
                if len(names) != 1: self.error("numeric for expects one loop variable")
                return NumericFor(names[0], start, limit, step, body)
            self.expect("in"); values = self.parse_exprlist(); self.expect("do")
            body = Block(self.parse_block({"end"})); self.expect("end")
            return GenericFor(names, values, body)
        if self.match("do"):
            body = Block(self.parse_block({"end"})); self.expect("end")
            return Do(body)
        if self.match("return"):
            if (isinstance(self.tok.value, str) and self.tok.value in BLOCK_END) or self.at(";"):
                return Return([])
            return Return(self.parse_exprlist())
        if self.at("break"):
            self.i += 1; return Break()
        if self.at("continue") and self.peek().value not in ("(", ".", "[", ":"):
            self.i += 1; return Continue()
        if self.match("goto"):
            return Goto(self.expect_name())
        if self.at("::"):
            self.i += 1; label = self.expect_name(); self.expect("::")
            return Label(label)
        # `type` and `export type` are compile-time-only declarations.
        if self.at("export") and self.peek().value == "type":
            self.i += 2; self._parse_type_alias(); return Noop()
        if self.at("type") and self.peek().kind == "NAME":
            self.i += 1; self._parse_type_alias(); return Noop()
        # Prefix expression followed by assignment/compound assignment/call.
        # In Lua/Luau, multiple assignment targets appear BEFORE `=`, e.g.
        # `a, b, t.x = 1, 2, 3`. Parse that target list before looking for
        # the assignment operator; parsing it only after `=` rejects valid code.
        first = self.parse_prefix_expr()
        targets = [first]
        if self.at(","):
            while self.match(","):
                targets.append(self.parse_prefix_expr())
            if not self.at("="):
                self.error("expected '=' after assignment targets")
            self.i += 1
            return Assign(targets, self.parse_exprlist())
        if self.tok.value in ("=", *COMPOUND):
            op = str(self.tok.value); self.i += 1
            values = self.parse_exprlist()
            return Assign(targets, values, None if op == "=" else op[:-1])
        if isinstance(first, Call): return CallStmt(first)
        self.error("expected assignment or function call statement")
        raise AssertionError

    def _parse_type_alias(self) -> None:
        self.expect_name()
        if self.at("<"):
            self._skip_angle_group()
        self.expect("=")
        self.parse_type()

    def _skip_angle_group(self) -> None:
        self.expect("<"); depth = 1
        while depth:
            if self.tok.kind == "EOF": self.error("unfinished generic type list")
            if self.match("<"): depth += 1
            elif self.match(">"): depth -= 1
            elif self.at(">>"):
                # The lexer normally tokenizes adjacent closing generic angles
                # as the shift operator. Inside a type argument list, consume
                # both closers so e.g. Outer<Inner<T>> remains parseable.
                self.i += 1; depth -= 2
                if depth < 0: self.error("unexpected extra generic closer")
            else: self.i += 1

    def parse_bindings(self) -> list[str]:
        names = [self.expect_name()]
        if self.match(":"): self.parse_type()
        while self.match(","):
            names.append(self.expect_name())
            if self.match(":"): self.parse_type()
        return names

    # Type parser: consume one complete type expression, but do not eat a
    # following statement. It covers names/generics, optional, union/intersection,
    # table and function types, typeof(expr), and array shorthand.
    def parse_type(self) -> None:
        self._parse_type_union()

    def _parse_type_union(self) -> None:
        self._parse_type_intersection()
        while self.match("|"):
            self._parse_type_intersection()

    def _parse_type_intersection(self) -> None:
        self._parse_type_atom()
        while self.match("&"):
            self._parse_type_atom()
        if self.match("->"):
            # Function return types can themselves be tuples or unions.
            if self.at("("):
                self._skip_balanced("(", ")")
                if self.match("->"): self._parse_type_union()
            else:
                self._parse_type_union()

    def _parse_type_atom(self) -> None:
        if self.match("?"):
            self._parse_type_atom(); return
        if self.match("typeof"):
            if self.at("("): self._skip_balanced("(", ")")
            return
        if self.at("{"):
            self._skip_balanced("{", "}")
        elif self.at("("):
            self._skip_balanced("(", ")")
        elif self.tok.kind == "NAME" or self.tok.kind == "KW":
            self.i += 1
            if self.at("<"):
                self._skip_angle_group()
        elif self.match("..."):
            if self.tok.kind == "NAME": self.i += 1
        else:
            self.error(f"expected type, got {self.tok.value!r}")
        if self.match("?"):
            pass
        while self.at("[") and self.peek().value == "]":
            self.i += 2
        if self.match("->"):
            self._parse_type_union()

    def parse_function_body(self) -> Function:
        if self.at("<"):
            self._skip_angle_group()
        self.expect("(")
        params: list[str] = []
        vararg = False
        if not self.at(")"):
            while True:
                if self.match("..."):
                    vararg = True
                    if self.match(":"): self.parse_type()
                    break
                params.append(self.expect_name())
                if self.match(":"): self.parse_type()
                if not self.match(","): break
        self.expect(")")
        if self.match(":"): self.parse_type()
        body = Block(self.parse_block({"end"})); self.expect("end")
        return Function(params, body, vararg)

    def parse_exprlist(self) -> list[Node]:
        vals = [self.parse_expr()]
        while self.match(","):
            vals.append(self.parse_expr())
        return vals

    def parse_expr(self, min_prec: int = 1) -> Node:
        if self.tok.kind in ("SYM", "KW") and isinstance(self.tok.value, str) and self.tok.value in UNARY:
            op = str(self.tok.value); self.i += 1
            left: Node = Unary(op, self.parse_expr(11))
        elif self.match("if"):
            cond = self.parse_expr(); self.expect("then")
            yes = self.parse_expr(); self.expect("else"); no = self.parse_expr()
            left = IfExpr(cond, yes, no)  # type: ignore[name-defined]
        else:
            left = self.parse_simple_expr()
        while True:
            # Type assertion/cast is erased at runtime.
            if self.at("::"):
                self.i += 1; self.parse_type(); continue
            op = str(self.tok.value)
            if op not in BIN_PREC: break
            lp, rp = BIN_PREC[op]
            if lp < min_prec: break
            self.i += 1
            right = self.parse_expr(rp + 1)
            left = Binary(op, left, right)
        return left

    def parse_simple_expr(self) -> Node:
        tok = self.tok
        if tok.kind == "NUMBER": self.i += 1; return Literal(tok.value)
        if tok.kind == "STRING": self.i += 1; return Literal(tok.value)
        if tok.value == "nil": self.i += 1; return Literal(None)
        if tok.value == "true": self.i += 1; return Literal(True)
        if tok.value == "false": self.i += 1; return Literal(False)
        if self.match("..."): return Vararg()
        if self.at("{"): return self.parse_table()
        if self.match("function"): return self.parse_function_body()
        if tok.kind == "INTERP":
            self.i += 1
            parts: list[tuple[str, object]] = []
            for kind, value in tok.value:  # type: ignore[union-attr]
                if kind == "text": parts.append((kind, value))
                else:
                    p = Parser(str(value))
                    expr = p.parse_expr()
                    p.expect("<eof>")
                    parts.append((kind, expr))
            return StringInterp(parts)
        if tok.kind in ("NAME",) or tok.value in ("(",):
            return self.parse_prefix_expr()
        self.error(f"expected expression, got {tok.value!r}")
        raise AssertionError

    def parse_prefix_expr(self) -> Node:
        if self.tok.kind == "NAME":
            expr: Node = Name(str(self.tok.value)); self.i += 1
        elif self.match("("):
            expr = self.parse_expr(); self.expect(")")
        else:
            self.error(f"expected prefix expression, got {self.tok.value!r}")
        while True:
            if self.match("."):
                expr = Index(expr, Literal(self.expect_name()))
            elif self.match("["):
                key = self.parse_expr(); self.expect("]")
                expr = Index(expr, key)
            elif self.match(":"):
                method = self.expect_name()
                args = self.parse_args()
                expr = Call(expr, args, method=method)
            elif self.at("(") or self.at("{") or self.tok.kind == "STRING":
                args = self.parse_args()
                expr = Call(expr, args)
            else:
                break
        return expr

    def parse_args(self) -> list[Node]:
        if self.match("("):
            if self.match(")"): return []
            args = self.parse_exprlist(); self.expect(")"); return args
        if self.at("{"):
            return [self.parse_table()]
        if self.tok.kind == "STRING":
            return [self.parse_simple_expr()]
        self.error("expected function arguments")
        raise AssertionError

    def parse_table(self) -> Table:
        self.expect("{")
        fields: list[TableField] = []
        while not self.at("}"):
            if self.match("["):
                key = self.parse_expr(); self.expect("]"); self.expect("=")
                fields.append(TableField("keyed", key, self.parse_expr()))
            elif self.tok.kind == "NAME" and self.peek().value == "=":
                key = Literal(self.expect_name()); self.expect("=")
                fields.append(TableField("keyed", key, self.parse_expr()))
            else:
                fields.append(TableField("array", None, self.parse_expr()))
            if not self.match(",") and not self.match(";"):
                break
            if self.at("}"): break
        self.expect("}")
        return Table(fields)


def parse(source: str) -> Chunk:
    return Parser(source).parse()
