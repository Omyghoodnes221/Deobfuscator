"""Custom VM instruction inventory. The build pipeline randomizes numeric IDs."""
OPCODES = [
    # Loads, stores, and upvalues
    "LOADK", "LOADBOOL", "LOADNIL", "LOADGLOBAL", "STOREGLOBAL", "MOVE",
    "GETUPVAL", "SETUPVAL",
    # Arithmetic and comparison
    "ADD", "SUB", "MUL", "DIV", "MOD", "POW", "IDIV", "UNM",
    "EQ", "NE", "LT", "LE", "GT", "GE",
    # Logic and bitwise
    "NOT", "AND", "OR", "BAND", "BOR", "BXOR", "BNOT", "SHL", "SHR",
    # Table and metatable
    "NEWTABLE", "GETTABLE", "SETTABLE", "GETFIELD", "SETFIELD", "LEN",
    "GETMETATABLE", "SETMETATABLE", "RAWGET", "RAWSET", "RAW_EQUAL", "RAW_LEN",
    # Functions and values
    "CALL", "TAILCALL", "RETURN", "CLOSURE", "VARARG", "SELF", "CONCAT",
    # Control flow and loops
    "JMP", "JMPIF", "JMPIFNOT", "TEST", "FORPREP", "FORLOOP", "TFORCALL", "TFORLOOP",
    "CLOSE", "NOP", "SETLIST",
]

# These are compiler-emittable instructions; the rest are reserved for VM
# compatibility and experimentation. They still have runtime handlers.
EMITTED = {
    "LOADK", "LOADBOOL", "LOADNIL", "LOADGLOBAL", "STOREGLOBAL", "MOVE",
    "GETUPVAL", "SETUPVAL", "ADD", "SUB", "MUL", "DIV", "MOD", "POW", "IDIV",
    "UNM", "EQ", "NE", "LT", "LE", "GT", "GE", "NOT", "BAND", "BOR", "BXOR",
    "BNOT", "SHL", "SHR", "NEWTABLE", "GETTABLE", "SETTABLE", "LEN", "CALL",
    "TAILCALL", "RETURN", "CLOSURE", "VARARG", "CONCAT", "JMP", "JMPIF",
    "JMPIFNOT", "FORPREP", "FORLOOP", "CLOSE", "NOP", "SETLIST",
}
