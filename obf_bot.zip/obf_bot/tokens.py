"""Tokenizer for the supported Luau source subset.

The tokenizer understands Lua/Luau comments, long strings, escapes, numeric
separators, compound operators and backtick interpolation. It is intentionally
separate from parsing so diagnostics retain source line/column information.
"""
from __future__ import annotations
from dataclasses import dataclass
import re
from typing import Iterator, Optional


@dataclass(frozen=True)
class Token:
    kind: str
    value: object
    line: int
    column: int
    offset: int

    def __repr__(self) -> str:
        return f"Token({self.kind}, {self.value!r}, {self.line}:{self.column})"


# Contextual Luau words (continue/const/type/export) are still lexed as names;
# the parser interprets them only in the appropriate syntactic position.
KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for",
    "function", "if", "in", "local", "nil", "not", "or", "repeat",
    "return", "then", "true", "until", "while",
}
OPERATORS = tuple(sorted({
    "...", "//=", "..=", ">>=", "<<=", "+=", "-=", "*=", "/=", "%=",
    "^=", "==", "~=", "<=", ">=", "//", "..", "->", "::", "<<", ">>",
    "<", ">", "=", "+", "-", "*", "/", "%", "^", "#", "&", "~", "|",
    "(", ")", "{", "}", "[", "]", ";", ":", ",", ".", "@", "?",
}, key=len, reverse=True))

_NUM_RE = re.compile(
    r"(?:"
    r"0[xX][0-9a-fA-F_]+|"
    r"0[bB][01_]+|"
    r"(?:[0-9][0-9_]*(?:\.(?!\.)[0-9_]*)?|\.[0-9][0-9_]*)(?:[eE][+-]?[0-9][0-9_]*)?"
    r")"
)
_NAME_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


class TokenizeError(SyntaxError):
    pass


class Tokenizer:
    def __init__(self, source: str):
        self.source = source
        self.n = len(source)
        self.i = 0
        self.line = 1
        self.col = 1

    def _peek(self, n: int = 0) -> str:
        j = self.i + n
        return self.source[j] if j < self.n else ""

    def _advance(self, count: int = 1) -> str:
        out = self.source[self.i:self.i + count]
        for ch in out:
            if ch == "\n":
                self.line += 1
                self.col = 1
            else:
                self.col += 1
        self.i += count
        return out

    def _long_bracket_open(self, at: Optional[int] = None) -> Optional[tuple[int, int]]:
        j = self.i if at is None else at
        if j >= self.n or self.source[j] != "[":
            return None
        k = j + 1
        while k < self.n and self.source[k] == "=":
            k += 1
        if k < self.n and self.source[k] == "[":
            return (k - j - 1, k - j + 1)
        return None

    def _read_long_bracket(self, is_comment: bool = False) -> str:
        opener = self._long_bracket_open()
        if opener is None:
            raise self._error("expected long-bracket opener")
        eqs, open_len = opener
        self._advance(open_len)
        close = "]" + ("=" * eqs) + "]"
        start = self.i
        end = self.source.find(close, self.i)
        if end < 0:
            raise self._error("unfinished long-bracket string/comment")
        content = self.source[start:end]
        self._advance(end - self.i + len(close))
        if content.startswith("\n") or content.startswith("\r\n"):
            content = content[1:] if content.startswith("\n") else content[2:]
        return content

    def _error(self, message: str) -> TokenizeError:
        return TokenizeError(f"{message} at line {self.line}, column {self.col}")

    @staticmethod
    def _decode_quoted(raw: str, line: int, column: int) -> str:
        out: list[str] = []
        i = 0
        while i < len(raw):
            ch = raw[i]
            if ch != "\\":
                out.append(ch)
                i += 1
                continue
            i += 1
            if i >= len(raw):
                raise TokenizeError(f"unfinished escape at line {line}, column {column}")
            e = raw[i]
            i += 1
            simple = {"a": "\a", "b": "\b", "f": "\f", "n": "\n", "r": "\r",
                      "t": "\t", "v": "\v", "\\": "\\", "\"": "\"", "'": "'"}
            if e in simple:
                out.append(simple[e])
            elif e == "z":
                while i < len(raw) and raw[i].isspace():
                    i += 1
            elif e == "x":
                digits = raw[i:i + 2]
                if len(digits) != 2 or not re.fullmatch(r"[0-9a-fA-F]{2}", digits):
                    raise TokenizeError(f"invalid \\x escape at line {line}, column {column}")
                out.append(chr(int(digits, 16)))
                i += 2
            elif e == "u" and i < len(raw) and raw[i] == "{":
                end = raw.find("}", i + 1)
                if end < 0:
                    raise TokenizeError(f"invalid Unicode escape at line {line}, column {column}")
                digits = raw[i + 1:end]
                try:
                    cp = int(digits, 16)
                    if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                        raise ValueError
                    out.append(chr(cp))
                except ValueError as exc:
                    raise TokenizeError(f"invalid Unicode code point at line {line}, column {column}") from exc
                i = end + 1
            elif e.isdigit():
                digits = e
                for _ in range(2):
                    if i < len(raw) and raw[i].isdigit():
                        digits += raw[i]
                        i += 1
                    else:
                        break
                val = int(digits, 10)
                if val > 255:
                    raise TokenizeError(f"decimal escape exceeds 255 at line {line}, column {column}")
                out.append(chr(val))
            elif e == "\n":
                out.append("\n")
            elif e == "\r":
                if i < len(raw) and raw[i] == "\n":
                    i += 1
                out.append("\n")
            else:
                # Luau rejects many unknown escapes; rejecting is safer than
                # silently rewriting code into a different program.
                raise TokenizeError(f"invalid escape \\{e} at line {line}, column {column}")
        return "".join(out)

    def _read_interpolation(self, line: int, col: int, offset: int) -> Token:
        # Consume opening backtick and split into literal/expression parts.
        self._advance()
        parts: list[tuple[str, str]] = []
        literal: list[str] = []
        while self.i < self.n:
            ch = self._peek()
            if ch == "`":
                self._advance()
                parts.append(("text", "".join(literal)))
                return Token("INTERP", parts, line, col, offset)
            if ch == "\\":
                self._advance()
                nxt = self._peek()
                if not nxt:
                    raise self._error("unfinished interpolation escape")
                self._advance()
                if nxt == "n": literal.append("\n")
                elif nxt == "t": literal.append("\t")
                elif nxt in ("`", "{", "\\"): literal.append(nxt)
                elif nxt in ("\n", "\r"): literal.append("\n")
                else: literal.extend(("\\", nxt))
                continue
            if ch == "{":
                if self._peek(1) == "{":
                    raise self._error("'{{' is not valid in string interpolation")
                parts.append(("text", "".join(literal)))
                literal.clear()
                self._advance()
                expr_start = self.i
                depth = 1
                quote: Optional[str] = None
                long_close: Optional[str] = None
                line_comment = False
                block_close: Optional[str] = None
                while self.i < self.n and depth:
                    c = self._peek()
                    if line_comment:
                        if c == "\n": line_comment = False
                        self._advance(); continue
                    if block_close:
                        if self.source.startswith(block_close, self.i):
                            self._advance(len(block_close)); block_close = None
                        else:
                            self._advance()
                        continue
                    if long_close:
                        if self.source.startswith(long_close, self.i):
                            self._advance(len(long_close)); long_close = None
                        else:
                            self._advance()
                        continue
                    if quote:
                        if c == "\\": self._advance(min(2, self.n - self.i)); continue
                        if c == quote: quote = None
                        self._advance(); continue
                    if self.source.startswith("--", self.i):
                        self._advance(2)
                        long_open = self._long_bracket_open()
                        if long_open:
                            eqs, olen = long_open
                            self._advance(olen)
                            block_close = "]" + "=" * eqs + "]"
                        else:
                            line_comment = True
                        continue
                    if c in ("'", '"'):
                        quote = c; self._advance(); continue
                    if c == "[":
                        op = self._long_bracket_open()
                        if op:
                            eqs, olen = op
                            self._advance(olen)
                            long_close = "]" + "=" * eqs + "]"
                            continue
                    if c == "{": depth += 1
                    elif c == "}": depth -= 1
                    if depth: self._advance()
                    else:
                        expr = self.source[expr_start:self.i]
                        parts.append(("expr", expr))
                        self._advance()
                if depth:
                    raise self._error("unfinished interpolation expression")
                continue
            literal.append(ch)
            self._advance()
        raise self._error("unfinished backtick string")

    def tokens(self) -> list[Token]:
        result: list[Token] = []
        while self.i < self.n:
            ch = self._peek()
            if ch.isspace():
                self._advance(); continue
            start, line, col = self.i, self.line, self.col
            if self.source.startswith("--", self.i):
                self._advance(2)
                if self._long_bracket_open():
                    self._read_long_bracket(True)
                else:
                    while self.i < self.n and self._peek() not in "\r\n": self._advance()
                continue
            if ch in ("'", '"'):
                quote = ch
                self._advance()
                raw_start = self.i
                while self.i < self.n:
                    c = self._peek()
                    if c == "\\":
                        self._advance(min(2, self.n - self.i)); continue
                    if c == quote: break
                    if c in "\r\n":
                        raise self._error("newline in quoted string")
                    self._advance()
                if self.i >= self.n:
                    raise self._error("unfinished quoted string")
                raw = self.source[raw_start:self.i]
                self._advance()
                value = self._decode_quoted(raw, line, col)
                result.append(Token("STRING", value, line, col, start)); continue
            if ch == "`":
                result.append(self._read_interpolation(line, col, start)); continue
            if ch == "[" and self._long_bracket_open():
                value = self._read_long_bracket()
                result.append(Token("STRING", value, line, col, start)); continue
            nm = _NAME_RE.match(self.source, self.i)
            if nm:
                value = nm.group(0)
                self._advance(len(value))
                kind = "KW" if value in KEYWORDS else "NAME"
                result.append(Token(kind, value, line, col, start)); continue
            num = _NUM_RE.match(self.source, self.i)
            if num:
                value = num.group(0)
                # Avoid treating the first dot of 1..2 as a decimal point.
                self._advance(len(value))
                raw = value.replace("_", "")
                try:
                    if raw.lower().startswith("0x"): numeric: object = int(raw, 16)
                    elif raw.lower().startswith("0b"): numeric = int(raw, 2)
                    elif any(c in raw for c in ".eE"): numeric = float(raw)
                    else: numeric = int(raw, 10)
                except ValueError as exc:
                    raise self._error(f"invalid number {value}") from exc
                result.append(Token("NUMBER", numeric, line, col, start)); continue
            found = None
            for op in OPERATORS:
                if self.source.startswith(op, self.i):
                    found = op; break
            if found:
                self._advance(len(found))
                result.append(Token("SYM", found, line, col, start)); continue
            raise self._error(f"unexpected character {ch!r}")
        result.append(Token("EOF", "<eof>", self.line, self.col, self.i))
        return result


def tokenize(source: str) -> list[Token]:
    return Tokenizer(source).tokens()
