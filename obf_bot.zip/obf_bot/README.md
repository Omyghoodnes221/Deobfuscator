# Lua Obfuscator Discord Bot

Attach a `.lua` / `.luau` / `.txt` file and type `.obfuscate` — the bot replies with the obfuscated file.

---

## Setup (GitHub → Render → UptimeRobot)

### 1. Discord Developer Portal
1. Go to https://discord.com/developers/applications → **New Application**
2. **Bot** tab → **Add Bot** → copy the **Token** (keep it secret!)
3. Under **Privileged Gateway Intents** turn on **Message Content Intent**
4. **OAuth2 → URL Generator**: scopes = `bot`, permissions = `Send Messages`, `Read Message History`, `Attach Files`
5. Open the generated URL and invite the bot to your server

### 2. GitHub
1. Create a new **private** repo (private = your token stays safe)
2. Push this entire folder as the repo root:
   ```
   git init
   git add .
   git commit -m "init"
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

### 3. Render
1. https://render.com → **New → Web Service** → connect your GitHub repo
2. Settings:
   - **Environment**: Python 3
   - **Build command**: `pip install -r requirements.txt`
   - **Start command**: `python bot.py`
3. **Environment Variables** (in Render dashboard → Environment tab):
   | Key | Value |
   |-----|-------|
   | `DISCORD_TOKEN` | your bot token |
   | `BOT_PREFIX` | `.` (or whatever you want) |
   | `ALLOWED_CHANNELS` | (optional) comma-separated channel IDs to restrict the command |
4. Click **Deploy** — Render will build and start the bot.

### 4. UptimeRobot (keeps Render free tier awake)
1. https://uptimerobot.com → **Add New Monitor**
2. **Monitor Type**: HTTP(s)
3. **URL**: your Render service URL (e.g. `https://your-bot.onrender.com`)
4. **Monitoring Interval**: every 5 minutes
5. Save — UptimeRobot will ping the bot every 5 min so Render doesn't sleep it.

---

## Usage

In any channel (or the ones you set in `ALLOWED_CHANNELS`):

```
.obfuscate          ← attach your .lua / .luau / .txt file
.obf                ← short alias
```

The bot replies with an embed showing stats + the obfuscated file attached.

---

## File structure

```
bot.py              ← Discord bot + keepalive HTTP server
obfuscator.py       ← obfuscation pipeline
vmgen.py            ← VM generator + anti-tamper (patched)
compiler.py
parser.py
tokens.py
ast_nodes.py
opcodes.py
stdlib.py
requirements.txt
Procfile
runtime.txt
README.md
```
