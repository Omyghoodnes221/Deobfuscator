"""Public obfuscation pipeline: tokenize -> parse -> compile -> randomized VM."""
from __future__ import annotations
from dataclasses import dataclass
import secrets
from typing import Any
from parser import parse
from compiler import Compiler
from opcodes import OPCODES
from vmgen import generate, signature, encode_constant


@dataclass
class BuildResult:
    source: str
    stats: dict[str, Any]


def obfuscate(source: str) -> BuildResult:
    tree = parse(source)
    compiler = Compiler()
    prototypes_obj, constants, root_id = compiler.compile(tree)
    pad_const = compiler.constants.add(0)
    proto_by_id = {p.id: p for p in prototypes_obj}

    rng = secrets.SystemRandom()
    available = list(range(100, 990))
    rng.shuffle(available)
    op_ids = {name: available[i] for i, name in enumerate(OPCODES)}
    decoy_ids = rng.sample(range(2000, 9000), rng.randint(8, 12))

    compiled_instruction_count = sum(
        1 for p in prototypes_obj for ins in p.code
        if ins[0] not in ("NOP", "CLOSE") and not str(ins[0]).startswith("DECOY:")
    )

    # Dead bytecode deliberately follows the terminal return/tailcall. The
    # interpreter has handlers for these fake IDs, but normal control flow can
    # never reach them unless the protected bytecode is modified.
    root = proto_by_id[root_id]
    for decoy in decoy_ids:
        root.code.append([f"DECOY:{decoy}", 900 + (decoy % 2), decoy % 17, 0, 0])
    dummy_count = rng.randint(5, 15)
    junk_patterns = [
        lambda: ["LOADK", 900, pad_const, 0, 0],
        lambda: ["MOVE", 901, 900, 0, 0],
        lambda: ["ADD", 902, 900, 901, 0],
        lambda: ["LOADBOOL", 903, rng.randint(0, 1), 0, 0],
        lambda: ["NOP", 0, 0, 0, 0],
    ]
    for _ in range(dummy_count): root.code.append(rng.choice(junk_patterns)())

    numeric_protos: list[dict[str, Any]] = []
    signatures: dict[int, int] = {}
    emitted_count = 0
    for p in sorted(prototypes_obj, key=lambda x: x.id):
        code: list[list[int]] = []
        for ins in p.code:
            mnemonic, a, b, c, d = ins
            if mnemonic.startswith("DECOY:"):
                opcode = int(mnemonic.split(":", 1)[1])
            else:
                opcode = op_ids[mnemonic]
            code.append([opcode, int(a), int(b), int(c), int(d)])
        signatures[p.id] = signature(code)
        numeric_protos.append({
            "id": p.id, "params": p.params, "vararg": p.vararg,
            "upvalues": p.upvalues, "code": code,
        })

    key = rng.randint(19, 231)
    out = generate(numeric_protos, constants, key=key, signatures=signatures,
                   op_ids=op_ids, decoy_ids=decoy_ids, root_id=root_id)
    # The generator collapses whitespace to a single physical line.
    if "\n" in out or "\r" in out:
        raise RuntimeError("internal error: output was not minified to one line")
    stats = {
        "prototypes": len(numeric_protos),
        "constants": len(constants),
        "instructions": sum(len(p["code"]) for p in numeric_protos),
        "source_instructions": compiled_instruction_count,
        "opcode_kinds": len(OPCODES),
        "decoy_opcodes": len(decoy_ids),
        "dummy_instructions": dummy_count,
        "encoded_bytes": sum(len(encode_constant(v, key)) for v in constants),
        "output_bytes": len(out.encode("utf-8")),
    }
    return BuildResult(out, stats)


def obfuscate_source(source: str) -> str:
    return obfuscate(source).source
