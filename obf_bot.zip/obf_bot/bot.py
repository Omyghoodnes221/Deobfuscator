"""Discord bot: .obfuscate <attach .lua/.txt> → returns obfuscated file."""
import os
import io
import sys
import traceback
import discord
from discord.ext import commands

# ── bootstrap: make sure the obfuscator package resolves from this folder ──
sys.path.insert(0, os.path.dirname(__file__))
from obfuscator import obfuscate  # noqa: E402

# ── config from env ─────────────────────────────────────────────────────────
TOKEN   = os.environ["DISCORD_TOKEN"]
PREFIX  = os.getenv("BOT_PREFIX", ".")
# Optional: restrict to specific channel IDs (comma-separated).
# Leave blank to allow any channel.
_CHANNEL_IDS_RAW = os.getenv("ALLOWED_CHANNELS", "")
ALLOWED_CHANNELS: set[int] = (
    {int(c.strip()) for c in _CHANNEL_IDS_RAW.split(",") if c.strip()}
    if _CHANNEL_IDS_RAW else set()
)

MAX_FILE_BYTES = 512 * 1024   # 512 KB input cap
ALLOWED_EXTS   = {".lua", ".luau", ".txt"}

# ── bot setup ────────────────────────────────────────────────────────────────
intents = discord.Intents.default()
intents.message_content = True          # needed to read attachments + content

bot = commands.Bot(command_prefix=PREFIX, intents=intents)


@bot.event
async def on_ready():
    print(f"[bot] logged in as {bot.user} (id={bot.user.id})")
    print(f"[bot] prefix={PREFIX!r}  allowed_channels={ALLOWED_CHANNELS or 'any'}")


@bot.command(name="obfuscate", aliases=["obf"])
async def cmd_obfuscate(ctx: commands.Context):
    """Usage: .obfuscate  (with a .lua / .luau / .txt file attached)"""

    # ── channel guard ────────────────────────────────────────────────────────
    if ALLOWED_CHANNELS and ctx.channel.id not in ALLOWED_CHANNELS:
        return

    # ── must have exactly one attachment ─────────────────────────────────────
    if not ctx.message.attachments:
        await ctx.reply(
            "❌ Please attach a `.lua`, `.luau`, or `.txt` file with the command.",
            mention_author=False,
        )
        return

    attachment = ctx.message.attachments[0]
    fname = attachment.filename
    ext   = os.path.splitext(fname)[1].lower()

    if ext not in ALLOWED_EXTS:
        await ctx.reply(
            f"❌ Unsupported file type `{ext}`. Use `.lua`, `.luau`, or `.txt`.",
            mention_author=False,
        )
        return

    if attachment.size > MAX_FILE_BYTES:
        await ctx.reply(
            f"❌ File too large ({attachment.size // 1024} KB). Max is 512 KB.",
            mention_author=False,
        )
        return

    # ── download & obfuscate ─────────────────────────────────────────────────
    async with ctx.typing():
        try:
            raw   = await attachment.read()
            source = raw.decode("utf-8")
        except UnicodeDecodeError:
            await ctx.reply("❌ Could not decode the file as UTF-8.", mention_author=False)
            return

        try:
            result      = obfuscate(source)
            obf_bytes   = result.source.encode("utf-8")
            stats       = result.stats
        except Exception:
            tb = traceback.format_exc()
            print(f"[obfuscate] error on {fname}:\n{tb}")
            await ctx.reply(
                "❌ Obfuscation failed. Make sure the file contains valid Lua/Luau.\n"
                f"```\n{tb[-800:]}\n```",
                mention_author=False,
            )
            return

    # ── send result ──────────────────────────────────────────────────────────
    out_name  = os.path.splitext(fname)[0] + "_obf.lua"
    out_file  = discord.File(io.BytesIO(obf_bytes), filename=out_name)

    embed = discord.Embed(
        title="✅ Obfuscation complete",
        colour=discord.Colour.green(),
    )
    embed.add_field(name="Prototypes",   value=str(stats["prototypes"]),         inline=True)
    embed.add_field(name="Instructions", value=str(stats["source_instructions"]), inline=True)
    embed.add_field(name="Output size",  value=f"{stats['output_bytes']:,} bytes", inline=True)
    embed.add_field(name="Opcode kinds", value=str(stats["opcode_kinds"]),        inline=True)
    embed.add_field(name="Decoy ops",    value=str(stats["decoy_opcodes"]),       inline=True)
    embed.add_field(name="Junk instr.",  value=str(stats["dummy_instructions"]),  inline=True)
    embed.set_footer(text=f"Input: {fname}  •  {len(source):,} chars → {stats['output_bytes']:,} bytes")

    await ctx.reply(embed=embed, file=out_file, mention_author=False)


# ── keepalive HTTP server (required by Render free tier) ────────────────────
def _start_keepalive():
    """Tiny HTTP server so Render sees the port and UptimeRobot can ping it."""
    from http.server import BaseHTTPRequestHandler, HTTPServer
    import threading

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK")

        def log_message(self, *_):
            pass   # silence request logs

    port = int(os.getenv("PORT", 8080))
    server = HTTPServer(("0.0.0.0", port), _Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    print(f"[keepalive] HTTP server listening on port {port}")


if __name__ == "__main__":
    _start_keepalive()
    bot.run(TOKEN)
