"""Small explicit AST for the Luau VM compiler."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional

@dataclass
class Node: pass
@dataclass
class Chunk(Node): body: list[Node]
@dataclass
class Block(Node): body: list[Node]
@dataclass
class Literal(Node): value: Any
@dataclass
class Name(Node): name: str
@dataclass
class Vararg(Node): pass
@dataclass
class Unary(Node): op: str; value: Node
@dataclass
class Binary(Node): op: str; left: Node; right: Node
@dataclass
class Index(Node): obj: Node; key: Node
@dataclass
class Call(Node): func: Node; args: list[Node]; method: Optional[str] = None
@dataclass
class TableField(Node): kind: str; key: Optional[Node]; value: Node
@dataclass
class Table(Node): fields: list[TableField]
@dataclass
class Function(Node): params: list[str]; body: Block; vararg: bool = False
@dataclass
class StringInterp(Node): parts: list[tuple[str, Any]]
@dataclass
class Local(Node): names: list[str]; values: list[Node]; const: bool = False
@dataclass
class Assign(Node): targets: list[Node]; values: list[Node]; op: Optional[str] = None
@dataclass
class CallStmt(Node): call: Node
@dataclass
class If(Node): clauses: list[tuple[Node, Block]]; otherwise: Optional[Block] = None
@dataclass
class While(Node): condition: Node; body: Block
@dataclass
class Repeat(Node): body: Block; condition: Node
@dataclass
class NumericFor(Node): name: str; start: Node; limit: Node; step: Node; body: Block
@dataclass
class GenericFor(Node): names: list[str]; values: list[Node]; body: Block
@dataclass
class Do(Node): body: Block
@dataclass
class Return(Node): values: list[Node]
@dataclass
class Break(Node): pass
@dataclass
class Continue(Node): pass
@dataclass
class FunctionDef(Node): target: Node; function: Function; local: bool = False
@dataclass
class Label(Node): name: str
@dataclass
class Goto(Node): name: str
@dataclass
class Noop(Node): pass

@dataclass
class IfExpr(Node):
    condition: Node
    yes: Node
    no: Node
