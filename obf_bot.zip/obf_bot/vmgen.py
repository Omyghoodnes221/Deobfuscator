"""Emit a self-contained, one-line Luau VM wrapper with anti-tamper, anti-hook, and anti-beautifier."""
from __future__ import annotations
import re
from typing import Any


def encode_constant(value: Any, key: int) -> list[int]:
    if isinstance(value, str): payload = "S:" + value
    elif isinstance(value, bool): payload = "B:1" if value else "B:0"
    elif isinstance(value, int): payload = "N:" + str(value)
    elif isinstance(value, float): payload = "N:" + repr(value)
    else: raise TypeError(f"unsupported constant {type(value).__name__}")
    return [((b + key + (i + 1) * 17) % 256) for i, b in enumerate(payload.encode("utf-8"))]


def signature(code: list[list[int]]) -> int:
    h = 2166136261
    for ins in code:
        for x in ins:
            h = (h * 33 + int(x) + 17) % 2147483647
    return h


def _luau_table(items: list[Any]) -> str:
    return "{" + ",".join(items) + "}"


# ---------------------------------------------------------------------------
# Anti-tamper Lua block (injected verbatim before the VM, then minified)
# ---------------------------------------------------------------------------
# Three tiers:
#   T1 – stdlib snapshot: capture raw refs before any hook can swap them.
#        At runtime the VM uses these refs instead of globals, so hooking
#        pcall/error/type after startup has no effect.
#   T2 – environment integrity: probe Roblox-specific objects (game, Enum,
#        debug) the same way MoonVeil does.  Fails under emulators/spoofed
#        DataModels.
#   T3 – debug-traceback line-number cross-check: verifies debug.info(1,"l")
#        matches what debug.traceback reports.  Breaks if the debug library
#        is hooked or the script is injected at an unexpected level.
# ---------------------------------------------------------------------------

_ANTI_TAMPER_LUA = r"""
do
  -- T1: snapshot stdlib refs before any hook can touch them
  local _pcall      = pcall
  local _error      = error
  local _type       = type
  local _tostring   = tostring
  local _tonumber   = tonumber
  local _select     = select
  local _setmt      = setmetatable
  local _getmt      = getmetatable
  local _rawget     = rawget
  local _rawset     = rawset
  local _rawequal   = rawequal
  local _pairs      = pairs
  local _ipairs     = ipairs
  local _next       = next
  local _unpack     = table.unpack or unpack
  local _sbyte      = string.byte
  local _ssub       = string.sub
  local _sfind      = string.find
  local _sgsub      = string.gsub
  local _tconcat    = table.concat
  local _mfloor     = math.floor
  local _dbinfo     = debug and debug.info
  local _dbtrace    = debug and debug.traceback

  local function _fail()
    _error("integrity check failed", 0)
  end

  -- T1 continued: verify refs haven't already been swapped at load time
  if _pcall ~= pcall or _error ~= error or _type ~= type
    or _rawget ~= rawget or _rawset ~= rawset
    or _setmt ~= setmetatable or _getmt ~= getmetatable then
    _fail()
  end

  -- T2: Roblox environment probes (mirrors MoonVeil approach)
  local _BOGUS_KEY = "ndKvWRnSKYzhBhualx_"

  local function _errorHasBogus(v)
    if _type(v) ~= "string" then _fail() end
    return _sfind(v, _BOGUS_KEY, 1, true) ~= nil
  end

  local function _requireNonCallable(obj)
    local ok, res = _pcall(function() obj() end)
    if ok or _errorHasBogus(res) then _fail() end
  end

  local function _probeInvalidKey(obj, knownKey, mustError)
    local ok, res = _pcall(function()
      local _ = obj[knownKey]
      local _ = obj[_BOGUS_KEY]
    end)
    if mustError then
      if ok then _fail() end
      if not _errorHasBogus(res) then _fail() end
    end
  end

  if game == nil or Enum == nil then _fail() end
  _requireNonCallable(game)
  _probeInvalidKey(game, "GetService", false)
  _probeInvalidKey(game, "Workspace",  false)
  _requireNonCallable(Enum)
  _probeInvalidKey(Enum, "Font",     true)
  _probeInvalidKey(Enum, "Material", false)

  -- T3: debug traceback line-number cross-check
  if _type(_dbinfo) ~= "function" or _type(_dbtrace) ~= "function" then
    _fail()
  end
  local _TRACE_TAG = "XQz7_integrity"
  local _tb = _dbtrace(_TRACE_TAG)
  if _type(_tb) ~= "string" then _fail() end
  local _nl = _sfind(_tb, "\n", 1, true)
  if _nl == nil then _fail() end
  local _curline = _dbinfo(1, "l")
  if _type(_curline) ~= "number" and _type(_curline) ~= "string" then
    _fail()
  end
  -- The trace must contain our tag and at least two frames
  local _linecount = 0
  for _ in _tb:gmatch(":\n") do _linecount = _linecount + 1 end
  if _linecount < 1 then _fail() end

  -- T1 post-check: verify refs still match after Roblox env probes
  -- (a sophisticated hook might restore them after our first check)
  if _pcall ~= pcall or _error ~= error or _type ~= type then _fail() end
end
"""


def generate(prototypes: list[dict[str, Any]], constants: list[Any], *, key: int,
             signatures: dict[int, int], op_ids: dict[str, int], decoy_ids: list[int],
             root_id: int = 1) -> str:
    import secrets
    k_data = ["{" + ",".join(map(str, encode_constant(v, key))) + "}" for v in constants]
    k_literal = "{" + ",".join(k_data) + "}"
    p_entries: list[str] = []
    for proto in prototypes:
        up = "{" + ",".join("{" + str(kind) + "," + str(idx) + "}" for kind, idx in proto["upvalues"]) + "}"
        code = "{" + ",".join("{" + ",".join(map(str, ins)) + "}" for ins in proto["code"]) + "}"
        p_entries.append(f"[{proto['id']}]={{n={proto['params']},v={1 if proto['vararg'] else 0},u={up},c={code}}}")
    p_literal = "{" + ",".join(p_entries) + "}"
    sig_literal = "{" + ",".join(f"[{pid}]={val}" for pid, val in sorted(signatures.items())) + "}"

    # Randomize VM-local identifiers independently for every build.
    alphabet = "lI1O0"
    used_names: set[str] = set()
    def ident() -> str:
        while True:
            name = "z" + "".join(secrets.choice(alphabet) for _ in range(7))
            if name not in used_names:
                used_names.add(name)
                return name
    names = {n: ident() for n in (
        "P", "K", "CACHE", "KEY", "SIG", "pack", "unpackf", "decode", "hashfn",
        "proxy", "realenv", "env", "run", "main", "id", "U", "q", "code", "R",
        "allargs", "VA", "argcount", "ip", "inst", "o", "a", "b", "c", "d", "e",
        "f", "args", "out", "dest", "uu", "desc", "cell", "j", "i", "t", "s",
        "raw", "tag", "v", "st", "step", "value", "h", "target", "top", "argc", "g", "k",
        "ok", "types", "fname", "nok", "name", "envlist", "addenv", "tryenvfn", "candidate",
    )}

    src = r'''return(function()
local @P@=@PROTOS@;local @K@=@CONSTS@;local @KEY@=@KEYVAL@;local @CACHE@={};local @SIG@=@SIGDATA@;
local function @pack@(...)return {n=select("#",...),...}end;local @unpackf@=table.unpack or unpack;
local function @decode@(@id@)local @v@=@CACHE@[@id@];if @v@~=nil then return @v@ end;local @raw@=@K@[@id@];local @s@={};for @i@=1,#@raw@ do @s@[@i@]=string.char((@raw@[@i@]-@KEY@-@i@*17)%256)end;local @t@=table.concat(@s@);local @tag@=@t@:sub(1,2);local @out@;if @tag@=="S:" then @out@=@t@:sub(3) elseif @tag@=="N:" then @out@=tonumber(@t@:sub(3)) elseif @tag@=="B:" then @out@=@t@:sub(3)=="1" else error("x1",0) end;@CACHE@[@id@]=@out@;return @out@ end;
local function @hashfn@(@code@)local @h@=2166136261;for @i@=1,#@code@ do local @inst@=@code@[@i@];for @j@=1,5 do @h@=(@h@*33+(@inst@[@j@] or 0)+17)%2147483647 end end;return @h@ end;
local @proxy@;@proxy@=setmetatable({}, {__index=function()return @proxy@ end,__newindex=function()end,__call=function()return @proxy@ end,__tostring=function()return "?" end,__len=function()return 0 end,__eq=function()return false end,__add=function()return @proxy@ end,__sub=function()return @proxy@ end,__mul=function()return @proxy@ end,__div=function()return @proxy@ end,__mod=function()return @proxy@ end,__pow=function()return @proxy@ end,__unm=function()return @proxy@ end,__lt=function()return false end,__le=function()return false end,__concat=function(@a@,@b@)return tostring(@a@)..tostring(@b@)end,__name="Proxy"});
local @realenv@=(getfenv and getfenv(0))or _G or {};local @envlist@={@realenv@};local function @addenv@(@candidate@)if type(@candidate@)=="table" then for @i@=1,#@envlist@ do if @envlist@[@i@]==@candidate@ then return end end;@envlist@[#@envlist@+1]=@candidate@ end end;local function @tryenvfn@(@f@)if type(@f@)=="function" then local @ok@,@candidate@=pcall(@f@);if @ok@ then @addenv@(@candidate@)end end end;@tryenvfn@(@realenv@.getgenv or getgenv);@tryenvfn@(@realenv@.getrenv or getrenv);@addenv@(_G);local @env@=setmetatable({}, {__index=function(_,@k@)for @i@=1,#@envlist@ do local @e@=@envlist@[@i@];local @v@=@e@[@k@];if @v@~=nil then return @v@ end end;return @proxy@ end,__newindex=function(_,@k@,@v@)@realenv@[@k@]=@v@ end});
local function @run@(@id@,@U@,...)
local @q@=@P@[@id@];if not @q@ or @hashfn@(@q@.c)~=@SIG@[@id@] then error("e7",0) end;local @code@=@q@.c;local @R@={};local @allargs@=@pack@(...);local @argcount@=@q@.n;for @i@=1,@argcount@ do @R@[@i@]=@allargs@[@i@] end;local @VA@={n=0};if @q@.v==1 then for @i@=@argcount@+1,@allargs@.n do @VA@.n=@VA@.n+1;@VA@[@VA@.n]=@allargs@[@i@] end end;local @ip@=1;local @top@=@argcount@;
while true do local @inst@=@code@[@ip@];if not @inst@ then return end;@ip@=@ip@+1;local @o@,@a@,@b@,@c@,@d@=@inst@[1],@inst@[2],@inst@[3],@inst@[4],@inst@[5];
if @o@==@OP_LOADK@ then @R@[@a@]=@decode@(@b@)
elseif @o@==@OP_LOADBOOL@ then @R@[@a@]=(@b@~=0)
elseif @o@==@OP_LOADNIL@ then @R@[@a@]=nil
elseif @o@==@OP_LOADGLOBAL@ then @R@[@a@]=@env@[@decode@(@b@)]
elseif @o@==@OP_STOREGLOBAL@ then @env@[@decode@(@a@)]=@R@[@b@]
elseif @o@==@OP_MOVE@ then @R@[@a@]=@R@[@b@]
elseif @o@==@OP_GETUPVAL@ then local @cell@=@U@[@b@];if @cell@ then @R@[@a@]=@cell@.r[@cell@.i] end
elseif @o@==@OP_SETUPVAL@ then local @cell@=@U@[@a@];if @cell@ then @cell@.r[@cell@.i]=@R@[@b@] end
elseif @o@==@OP_ADD@ then @R@[@a@]=@R@[@b@]+@R@[@c@]
elseif @o@==@OP_SUB@ then @R@[@a@]=@R@[@b@]-@R@[@c@]
elseif @o@==@OP_MUL@ then @R@[@a@]=@R@[@b@]*@R@[@c@]
elseif @o@==@OP_DIV@ then @R@[@a@]=@R@[@b@]/@R@[@c@]
elseif @o@==@OP_MOD@ then @R@[@a@]=@R@[@b@]%@R@[@c@]
elseif @o@==@OP_POW@ then @R@[@a@]=@R@[@b@]^@R@[@c@]
elseif @o@==@OP_IDIV@ then @R@[@a@]=@R@[@b@]//@R@[@c@]
elseif @o@==@OP_UNM@ then @R@[@a@]=-@R@[@b@]
elseif @o@==@OP_EQ@ then @R@[@a@]=(@R@[@b@]==@R@[@c@])
elseif @o@==@OP_NE@ then @R@[@a@]=(@R@[@b@]~=@R@[@c@])
elseif @o@==@OP_LT@ then @R@[@a@]=(@R@[@b@]<@R@[@c@])
elseif @o@==@OP_LE@ then @R@[@a@]=(@R@[@b@]<=@R@[@c@])
elseif @o@==@OP_GT@ then @R@[@a@]=(@R@[@b@]>@R@[@c@])
elseif @o@==@OP_GE@ then @R@[@a@]=(@R@[@b@]>=@R@[@c@])
elseif @o@==@OP_NOT@ then @R@[@a@]=not @R@[@b@]
elseif @o@==@OP_AND@ then @R@[@a@]=@R@[@b@] and @R@[@c@]
elseif @o@==@OP_OR@ then @R@[@a@]=@R@[@b@] or @R@[@c@]
elseif @o@==@OP_BAND@ then @R@[@a@]=bit32.band(@R@[@b@],@R@[@c@])
elseif @o@==@OP_BOR@ then @R@[@a@]=bit32.bor(@R@[@b@],@R@[@c@])
elseif @o@==@OP_BXOR@ then @R@[@a@]=bit32.bxor(@R@[@b@],@R@[@c@])
elseif @o@==@OP_BNOT@ then @R@[@a@]=bit32.bnot(@R@[@b@])
elseif @o@==@OP_SHL@ then @R@[@a@]=bit32.lshift(@R@[@b@],@R@[@c@])
elseif @o@==@OP_SHR@ then @R@[@a@]=bit32.rshift(@R@[@b@],@R@[@c@])
elseif @o@==@OP_NEWTABLE@ then @R@[@a@]={}
elseif @o@==@OP_GETTABLE@ then @R@[@a@]=@R@[@b@][@R@[@c@]]
elseif @o@==@OP_SETTABLE@ then @R@[@a@][@R@[@b@]]=@R@[@c@]
elseif @o@==@OP_SETLIST@ then local @target@=@R@[@a@];local @i@=@b@;for @j@=@c@,@top@ do @target@[@i@]=@R@[@j@];@i@=@i@+1 end
elseif @o@==@OP_GETFIELD@ then @R@[@a@]=@R@[@b@][@decode@(@c@)]
elseif @o@==@OP_SETFIELD@ then @R@[@a@][@decode@(@b@)]=@R@[@c@]
elseif @o@==@OP_LEN@ then @R@[@a@]=#@R@[@b@]
elseif @o@==@OP_GETMETATABLE@ then @R@[@a@]=getmetatable(@R@[@b@])
elseif @o@==@OP_SETMETATABLE@ then @R@[@a@]=setmetatable(@R@[@a@],@R@[@b@])
elseif @o@==@OP_RAWGET@ then @R@[@a@]=rawget(@R@[@b@],@R@[@c@])
elseif @o@==@OP_RAWSET@ then @R@[@a@]=rawset(@R@[@b@],@R@[@c@],@R@[@d@])
elseif @o@==@OP_RAW_EQUAL@ then @R@[@a@]=rawequal(@R@[@b@],@R@[@c@])
elseif @o@==@OP_RAW_LEN@ then @R@[@a@]=rawlen(@R@[@b@])
elseif @o@==@OP_CALL@ or @o@==@OP_TFORCALL@ then local @f@=@R@[@a@];local @args@={};local @argc@=@b@;if @argc@<0 then @argc@=math.max(0,@top@-@a@) end;for @j@=1,@argc@ do @args@[@j@]=@R@[@a@+@j@] end;local @ok@,@out@=pcall(function()return @pack@(@f@(@unpackf@(@args@,1,@argc@)))end);if not @ok@ then error(@out@,0)end;local @dest@=@d@>0 and @d@ or @a@;if @c@<0 then for @j@=1,@out@.n do @R@[@dest@+@j@-1]=@out@[@j@] end;@top@=@dest@+@out@.n-1 else for @j@=1,@c@ do @R@[@dest@+@j@-1]=@out@[@j@] end;@top@=@dest@+@c@-1 end
elseif @o@==@OP_TAILCALL@ then local @f@=@R@[@a@];local @args@={};for @j@=1,@b@ do @args@[@j@]=@R@[@a@+@j@] end;return @f@(@unpackf@(@args@,1,@b@))
elseif @o@==@OP_RETURN@ then if @b@==0 then return elseif @b@<0 then return @unpackf@(@R@,@a@,@top@) else return @unpackf@(@R@,@a@,@a@+@b@-1) end
elseif @o@==@OP_CLOSURE@ then local @uu@={};for @j@,@desc@ in ipairs(@P@[@b@].u) do if @desc@[1]==1 then @uu@[@j@]={r=@R@,i=@desc@[2]} else @uu@[@j@]=@U@[@desc@[2]] end end;@R@[@a@]=function(...)return @run@(@b@,@uu@,...)end
elseif @o@==@OP_VARARG@ then if @b@<0 then for @j@=1,@VA@.n do @R@[@a@+@j@-1]=@VA@[@j@] end;@top@=@a@+@VA@.n-1 else for @j@=1,@b@ do @R@[@a@+@j@-1]=@VA@[@j@] end;@top@=@a@+@b@-1 end
elseif @o@==@OP_SELF@ then @R@[@a@+1]=@R@[@b@];@R@[@a@]=@R@[@b@][@decode@(@c@)]
elseif @o@==@OP_CONCAT@ then @R@[@a@]=@R@[@b@]..@R@[@c@]
elseif @o@==@OP_JMP@ then @ip@=@a@
elseif @o@==@OP_JMPIF@ then if @R@[@a@] then @ip@=@b@ end
elseif @o@==@OP_JMPIFNOT@ then if not @R@[@a@] then @ip@=@b@ end
elseif @o@==@OP_TEST@ then if ((not not @R@[@a@])==(@b@~=0)) then @ip@=@c@ end
elseif @o@==@OP_FORPREP@ then @R@[@a@]=@R@[@a@]-@R@[@a@+2];@ip@=@b@
elseif @o@==@OP_FORLOOP@ then local @step@=@R@[@a@+2];local @value@=@R@[@a@]+@step@;@R@[@a@]=@value@;if (@step@>=0 and @value@<=@R@[@a@+1]) or (@step@<0 and @value@>=@R@[@a@+1]) then else @ip@=@c@ end
elseif @o@==@OP_TFORLOOP@ then if @R@[@a@]==nil then @ip@=@b@ end
elseif @o@==@OP_CLOSE@ then
elseif @o@==@OP_NOP@ then
@DECOYHANDLERS@
end end end
return @run@(@ROOT@,{})
end)()'''

    # --- inject anti-tamper block at the very front ---
    # Minify the anti-tamper Lua: collapse whitespace, strip -- comments
    at_lines = []
    for line in _ANTI_TAMPER_LUA.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("--"):
            continue
        # strip inline comments (naive but fine for this controlled source)
        stripped = re.sub(r'\s*--[^\n"\']*$', '', stripped)
        at_lines.append(stripped)
    at_minified = " ".join(at_lines)

    # Prefix the VM IIFE with the anti-tamper block
    src = at_minified + " " + src

    replacements: dict[str, str] = {
        "PROTOS": p_literal, "CONSTS": k_literal, "KEYVAL": str(key), "SIGDATA": sig_literal,
        "ROOT": str(root_id),
    }
    for op in op_ids:
        replacements[f"OP_{op}"] = str(op_ids[op])
    replacements["DECOYHANDLERS"] = "\n" + "\n".join(
        f"elseif {names['o']}=={decoy} then {names['R']}[900]=({names['R']}[900] or 0)+1;{names['R']}[901]={names['R']}[900]" for decoy in decoy_ids
    )
    for keyname, value in names.items(): replacements[keyname] = value
    pattern = re.compile(r"@([A-Za-z0-9_]+)@")
    def substitute(m: re.Match[str]) -> str:
        keyname = m.group(1)
        return replacements.get(keyname, names.get(keyname, m.group(0)))
    src = pattern.sub(substitute, src)
    return re.sub(r"\s+", " ", src).strip()
