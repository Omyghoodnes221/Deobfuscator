"""Manifest for runtime-native Luau libraries.

The generated VM deliberately delegates standard-library behavior to the
actual Luau runtime instead of reimplementing it in Python. This preserves the
engine's metatables, userdata, scheduler, and platform-specific semantics.
"""
from __future__ import annotations

GLOBAL_FUNCTIONS = {
    "assert", "error", "getfenv", "getmetatable", "ipairs", "loadstring",
    "newproxy", "next", "pairs", "pcall", "print", "rawequal", "rawget",
    "rawlen", "rawset", "require", "select", "setfenv", "setmetatable",
    "tonumber", "tostring", "type", "typeof", "unpack", "xpcall", "warn",
}

LIBRARY_FUNCTIONS = {
    "string": {
        "byte", "char", "find", "format", "gmatch", "gsub", "len", "lower",
        "match", "rep", "reverse", "sub", "upper", "split",
    },
    "table": {
        "clear", "clone", "concat", "create", "find", "freeze", "isfrozen",
        "insert", "maxn", "move", "pack", "remove", "sort", "unpack",
    },
    "math": {
        "abs", "acos", "asin", "atan", "atan2", "ceil", "clamp", "cos",
        "cosh", "deg", "exp", "floor", "fmod", "frexp", "huge", "isfinite",
        "isinf", "isnan", "ldexp", "lerp", "log", "log10", "map", "max",
        "min", "modf", "pi", "pow", "rad", "random", "randomseed", "round",
        "sign", "sin", "sinh", "sqrt", "tan", "tanh",
    },
    "coroutine": {"close", "create", "isyieldable", "resume", "running", "status", "wrap", "yield"},
    "os": {"clock", "date", "difftime", "time"},
    "bit32": {"arshift", "band", "bnot", "bor", "btest", "bxor", "extract", "lrotate", "lshift", "replace", "rrotate", "rshift"},
    "utf8": {"char", "codes", "codepoint", "len", "offset", "nfcnormalize", "nfdnormalize", "graphemes"},
}


def manifest() -> dict[str, object]:
    """Return a plain-data inventory usable by docs/tests."""
    return {
        "global_functions": sorted(GLOBAL_FUNCTIONS),
        "libraries": {name: sorted(items) for name, items in LIBRARY_FUNCTIONS.items()},
        "implementation": "native Luau runtime pass-through; not a Python reimplementation",
    }
