"""Register-bytecode compiler for the supported Luau subset.

This is a real compiler pipeline (AST -> custom register instructions), but is
not a drop-in replacement for the official Luau compiler. Unsupported syntax
raises a diagnostic rather than being copied to the output.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
from ast_nodes import *
from opcodes import OPCODES


class CompileError(Exception):
    pass


@dataclass
class ConstantPool:
    values: list[Any] = field(default_factory=list)
    index: dict[tuple[str, Any], int] = field(default_factory=dict)

    @staticmethod
    def key(value: Any) -> tuple[str, Any]:
        if isinstance(value, float) and value != value: return ("float", "nan")
        if isinstance(value, (str, int, float, bool, type(None))): return (type(value).__name__, value)
        raise CompileError(f"unsupported constant type: {type(value).__name__}")

    def add(self, value: Any) -> int:
        key = self.key(value)
        if key in self.index: return self.index[key]
        self.values.append(value)
        idx = len(self.values)
        self.index[key] = idx
        return idx


@dataclass
class Prototype:
    id: int
    params: int
    vararg: bool
    upvalues: list[tuple[int, int]] = field(default_factory=list)
    code: list[list[Any]] = field(default_factory=list)
    max_register: int = 0


@dataclass
class LoopState:
    continue_target: int
    breaks: list[int] = field(default_factory=list)


class Compiler:
    def __init__(self):
        self.constants = ConstantPool()
        self.prototypes: list[Optional[Prototype]] = [None]
        self.root: Optional[int] = None

    def compile(self, chunk: Chunk) -> tuple[list[Prototype], list[Any], int]:
        proto_id = len(self.prototypes)
        self.prototypes.append(None)
        fc = FunctionCompiler(self, proto_id, None, [], False)
        fc.compile_block(Block(chunk.body), scoped=False)
        if not fc.code or fc.code[-1][0] not in ("RETURN", "TAILCALL"):
            fc.emit("RETURN", 0, 0)
        fc.resolve_gotos()
        fc.inject_unreachable_padding()
        proto = Prototype(proto_id, 0, False, fc.upvalues, fc.code, fc.max_register)
        self.prototypes[proto_id] = proto
        self.root = proto_id
        return [p for p in self.prototypes[1:] if p is not None], self.constants.values, proto_id


class FunctionCompiler:
    def __init__(self, owner: Compiler, proto_id: int, parent: Optional["FunctionCompiler"],
                 params: list[str], vararg: bool):
        self.owner = owner
        self.proto_id = proto_id
        self.parent = parent
        self.params = params
        self.vararg = vararg
        self.code: list[list[Any]] = []  # [mnemonic, A, B, C, D]
        # Permanent registers hold parameters, locals, and loop state. Scratch
        # registers are reused after each statement; the previous allocator
        # monotonically advanced for every temporary and eventually hit 5000
        # even for ordinary long scripts.
        self.reserved_registers: set[int] = set()
        self.temp_registers: set[int] = set()
        self.max_register = 0
        self.scopes: list[dict[str, int]] = [{}]
        # Local registers whose lexical scopes have ended can be recycled,
        # except registers captured by closures (the VM currently models those
        # as open cells pointing directly into the frame register table).
        self.scope_registers: list[set[int]] = [set()]
        self.captured_registers: set[int] = set()
        self.upvalues: list[tuple[int, int]] = []
        self.upvalue_index: dict[tuple[int, int], int] = {}
        self.loops: list[LoopState] = []
        self.labels: dict[str, int] = {}
        self.pending_gotos: list[tuple[int, str]] = []
        for i, name in enumerate(params, 1):
            self.scopes[0][name] = i
            self.reserved_registers.add(i)
        self.max_register = len(params)

    def _find_register_range(self, count: int) -> int:
        count = max(1, count)
        occupied = self.reserved_registers | self.temp_registers
        base = 1
        while True:
            # Register windows used for calls/varargs must be contiguous.
            conflict = next((r for r in range(base, base + count) if r in occupied), None)
            if conflict is None:
                highest = base + count - 1
                if highest > 50000000000000000000000000000000000:
                    raise CompileError(
                        "register pressure exceeds 5000 simultaneously live registers; "
                        "check for unusually many locals or a compiler allocation bug"
                    )
                self.max_register = max(self.max_register, highest)
                return base
            base = conflict + 1

    def alloc(self, count: int = 1) -> int:
        """Allocate short-lived scratch registers, reusable after a statement."""
        count = max(1, count)
        base = self._find_register_range(count)
        self.temp_registers.update(range(base, base + count))
        return base

    def alloc_local(self, count: int = 1) -> int:
        """Reserve registers for locals or loop state that must survive statements."""
        count = max(1, count)
        base = self._find_register_range(count)
        regs = set(range(base, base + count))
        self.reserved_registers.update(regs)
        self.scope_registers[-1].update(regs)
        return base

    def release_temps(self) -> None:
        self.temp_registers.clear()

    def emit(self, op: str, a: int = 0, b: int = 0, c: int = 0, d: int = 0) -> int:
        if op not in OPCODES: raise CompileError(f"unknown opcode {op}")
        self.code.append([op, int(a or 0), int(b or 0), int(c or 0), int(d or 0)])
        return len(self.code)  # one-based PC

    def patch(self, pc: int, operand: str, value: int) -> None:
        slot = {"a": 1, "b": 2, "c": 3, "d": 4}[operand.lower()]
        self.code[pc - 1][slot] = value

    def push_scope(self) -> None:
        self.scopes.append({})
        self.scope_registers.append(set())

    def pop_scope(self) -> None:
        if len(self.scopes) <= 1:
            return
        self.scopes.pop()
        regs = self.scope_registers.pop()
        for reg in regs:
            if reg not in self.captured_registers:
                self.reserved_registers.discard(reg)
    def bind(self, name: str, reg: int) -> None: self.scopes[-1][name] = reg

    def find_local(self, name: str) -> Optional[int]:
        for scope in reversed(self.scopes):
            if name in scope: return scope[name]
        return None

    def capture_for_child(self, name: str) -> Optional[tuple[int, int]]:
        reg = self.find_local(name)
        if reg is not None:
            self.captured_registers.add(reg)
            return (1, reg)  # child's upvalue points to this frame's register
        up = self._capture_upvalue(name)
        if up is not None: return (2, up)
        return None

    def _capture_upvalue(self, name: str) -> Optional[int]:
        if self.parent is None: return None
        desc = self.parent.capture_for_child(name)
        if desc is None: return None
        if desc in self.upvalue_index: return self.upvalue_index[desc]
        self.upvalues.append(desc)
        idx = len(self.upvalues)
        self.upvalue_index[desc] = idx
        return idx

    def resolve_name(self, name: str) -> tuple[str, int]:
        local = self.find_local(name)
        if local is not None: return ("local", local)
        up = self._capture_upvalue(name)
        if up is not None: return ("up", up)
        return ("global", self.owner.constants.add(name))

    def compile_block(self, block: Block, scoped: bool = True) -> None:
        if scoped: self.push_scope()
        for stmt in block.body: self.compile_stmt(stmt)
        if scoped: self.pop_scope()

    def compile_stmt(self, stmt: Node) -> None:
        try:
            self._compile_stmt(stmt)
        finally:
            # Values produced while compiling one statement are dead after its
            # generated instructions have consumed them. Keep locals and loop
            # state pinned, but recycle scratch registers for the next statement.
            self.release_temps()

    def _compile_stmt(self, stmt: Node) -> None:
        if isinstance(stmt, Noop): return
        if isinstance(stmt, Local):
            # RHS is evaluated before the new local bindings become visible.
            vals = self.compile_values(stmt.values, len(stmt.names)) if stmt.values else []
            regs = [self.alloc_local() for _ in stmt.names]
            for name, reg in zip(stmt.names, regs): self.bind(name, reg)
            for i, reg in enumerate(regs):
                if i < len(vals): self.emit("MOVE", reg, vals[i])
                else: self.emit("LOADNIL", reg)
            return
        if isinstance(stmt, FunctionDef):
            if stmt.local and isinstance(stmt.target, Name):
                reg = self.alloc_local(); self.bind(stmt.target.name, reg)
                child = self.compile_function(stmt.function)
                self.emit("CLOSURE", reg, child)
            else:
                target = self.prepare_lvalue(stmt.target)
                child = self.compile_function(stmt.function)
                value = self.alloc(); self.emit("CLOSURE", value, child)
                self.store_target(target, value)
            return
        if isinstance(stmt, Assign):
            targets = [self.prepare_lvalue(t) for t in stmt.targets]
            if stmt.op:
                old = self.read_target(targets[0])
                right = self.compile_expr(stmt.values[0])
                out = self.alloc(); self.emit(self.binary_opcode(stmt.op), out, old, right)
                self.store_target(targets[0], out)
            else:
                vals = self.compile_values(stmt.values, len(targets))
                for target, value in zip(targets, vals): self.store_target(target, value)
            return
        if isinstance(stmt, CallStmt):
            self.compile_call(stmt.call, 0)
            return
        if isinstance(stmt, If):
            end_jumps: list[int] = []
            for cond, body in stmt.clauses:
                test = self.compile_expr(cond)
                false_jump = self.emit("JMPIFNOT", test, 0)
                self.compile_block(body)
                end_jumps.append(self.emit("JMP", 0))
                self.patch(false_jump, "b", len(self.code) + 1)
            if stmt.otherwise is not None: self.compile_block(stmt.otherwise)
            end = len(self.code) + 1
            for j in end_jumps: self.patch(j, "a", end)
            return
        if isinstance(stmt, While):
            start = len(self.code) + 1
            test = self.compile_expr(stmt.condition)
            exit_jump = self.emit("JMPIFNOT", test, 0)
            loop = LoopState(start); self.loops.append(loop)
            self.compile_block(stmt.body)
            self.emit("JMP", start)
            end = len(self.code) + 1; self.patch(exit_jump, "b", end)
            for j in loop.breaks: self.patch(j, "a", end)
            self.loops.pop(); return
        if isinstance(stmt, Repeat):
            start = len(self.code) + 1
            self.push_scope()
            loop = LoopState(0); self.loops.append(loop)
            self.compile_block(stmt.body, scoped=False)
            loop.continue_target = len(self.code) + 1
            cond = self.compile_expr(stmt.condition)
            self.emit("JMPIFNOT", cond, start)
            end = len(self.code) + 1
            for j in loop.breaks: self.patch(j, "a", end)
            self.loops.pop(); self.pop_scope(); return
        if isinstance(stmt, NumericFor):
            start_val = self.compile_expr(stmt.start)
            limit_val = self.compile_expr(stmt.limit)
            step_val = self.compile_expr(stmt.step)
            self.push_scope()
            base = self.alloc_local(3)
            self.emit("MOVE", base, start_val); self.emit("MOVE", base + 1, limit_val); self.emit("MOVE", base + 2, step_val)
            self.bind(stmt.name, base)
            prep = self.emit("FORPREP", base, 0)
            loop_pc = len(self.code) + 1
            self.patch(prep, "b", loop_pc)
            loopback = self.emit("FORLOOP", base, 0, 0)
            self.patch(loopback, "c", 0)  # patched to exit after body is known
            loop = LoopState(loop_pc); self.loops.append(loop)
            body_start = len(self.code) + 1
            # The FORLOOP falls through into the body on each successful iteration.
            self.compile_block(stmt.body)
            self.emit("JMP", loop_pc)
            end = len(self.code) + 1
            self.patch(loopback, "c", end)
            for j in loop.breaks: self.patch(j, "a", end)
            self.loops.pop(); self.pop_scope(); return
        if isinstance(stmt, GenericFor):
            # Luau generic-for keeps the iterator/state/control triple intact
            # across iterations. The prior implementation wrote iterator
            # results over the iterator function register, so a second
            # iteration attempted to call the previous result instead.
            vals = self.compile_values(stmt.values, 3)
            self.push_scope()
            base = self.alloc_local(3)
            for i, r in enumerate(vals): self.emit("MOVE", base + i, r)
            loop_start = len(self.code) + 1
            result_count = max(1, len(stmt.names))
            callbase = self.alloc_local(3 + result_count)
            resultbase = callbase + 3
            self.emit("MOVE", callbase, base)
            self.emit("MOVE", callbase + 1, base + 1)
            self.emit("MOVE", callbase + 2, base + 2)
            # D is an explicit result destination; keep A (the iterator) intact.
            self.emit("CALL", callbase, 2, len(stmt.names), resultbase)
            nilreg = self.alloc_local(); self.emit("LOADNIL", nilreg)
            is_nil = self.alloc_local(); self.emit("EQ", is_nil, resultbase, nilreg)
            exit_jump = self.emit("JMPIF", is_nil, 0)
            self.emit("MOVE", base + 2, resultbase)  # control becomes first result
            self.push_scope()
            for i, name in enumerate(stmt.names):
                lr = self.alloc_local(); self.bind(name, lr); self.emit("MOVE", lr, resultbase + i)
            loop = LoopState(loop_start); self.loops.append(loop)
            self.compile_block(stmt.body)
            self.emit("JMP", loop_start)
            end = len(self.code) + 1; self.patch(exit_jump, "b", end)
            for j in loop.breaks: self.patch(j, "a", end)
            self.loops.pop(); self.pop_scope(); self.pop_scope(); return
        if isinstance(stmt, Do):
            self.compile_block(stmt.body); return
        if isinstance(stmt, Return):
            if not stmt.values:
                self.emit("RETURN", 0, 0); return
            if len(stmt.values) == 1 and isinstance(stmt.values[0], Call):
                call = stmt.values[0]
                if call.args and isinstance(call.args[-1], (Call, Vararg)):
                    base = self.compile_call(call, -1)
                    self.emit("RETURN", base, -1)
                else:
                    self.compile_call(call, -1, tail=True)
                return
            if len(stmt.values) == 1 and isinstance(stmt.values[0], Vararg):
                base = self.alloc(); self.emit("VARARG", base, -1); self.emit("RETURN", base, -1); return
            if isinstance(stmt.values[-1], (Call, Vararg)):
                prefix = [self.compile_expr(e) for e in stmt.values[:-1]]
                outbase = self.alloc(max(1, len(prefix) + 1))
                for i, r in enumerate(prefix): self.emit("MOVE", outbase + i, r)
                if isinstance(stmt.values[-1], Call):
                    self.compile_call(stmt.values[-1], -1, output_base=outbase + len(prefix))
                else:
                    self.emit("VARARG", outbase + len(prefix), -1)
                self.emit("RETURN", outbase, -1); return
            vals = [self.compile_expr(e) for e in stmt.values]
            base = self.alloc(len(vals))
            for i, r in enumerate(vals): self.emit("MOVE", base + i, r)
            self.emit("RETURN", base, len(vals)); return
        if isinstance(stmt, Break):
            if not self.loops: raise CompileError("break outside loop")
            self.loops[-1].breaks.append(self.emit("JMP", 0)); return
        if isinstance(stmt, Continue):
            if not self.loops: raise CompileError("continue outside loop")
            target = self.loops[-1].continue_target
            if target <= 0: raise CompileError("invalid continue target")
            self.emit("JMP", target); return
        if isinstance(stmt, Label):
            self.labels[stmt.name] = len(self.code) + 1; return
        if isinstance(stmt, Goto):
            self.pending_gotos.append((self.emit("JMP", 0), stmt.name)); return
        raise CompileError(f"unsupported statement node: {type(stmt).__name__}")

    def resolve_gotos(self) -> None:
        for pc, name in self.pending_gotos:
            if name not in self.labels: raise CompileError(f"unknown label ::{name}::")
            self.patch(pc, "a", self.labels[name])

    def inject_unreachable_padding(self) -> None:
        # Junk follows a terminal return. It contributes no execution behavior.
        if not self.code or self.code[-1][0] not in ("RETURN", "TAILCALL"):
            self.emit("RETURN", 0, 0)
        self.emit("JMP", len(self.code) + 4)
        self.emit("LOADBOOL", 900, 1)
        self.emit("MOVE", 901, 900)
        self.emit("JMP", len(self.code) + 1)
        self.emit("NOP")

    def compile_function(self, fn: Function) -> int:
        pid = len(self.owner.prototypes)
        self.owner.prototypes.append(None)
        child = FunctionCompiler(self.owner, pid, self, fn.params, fn.vararg)
        child.compile_block(fn.body, scoped=True)
        if not child.code or child.code[-1][0] not in ("RETURN", "TAILCALL"):
            child.emit("RETURN", 0, 0)
        child.resolve_gotos()
        child.inject_unreachable_padding()
        self.owner.prototypes[pid] = Prototype(pid, len(fn.params), fn.vararg, child.upvalues, child.code, child.max_register)
        return pid

    def binary_opcode(self, op: str) -> str:
        return {
            "+": "ADD", "-": "SUB", "*": "MUL", "/": "DIV", "//": "IDIV",
            "%": "MOD", "^": "POW", "..": "CONCAT", "==": "EQ", "~=": "NE",
            "<": "LT", "<=": "LE", ">": "GT", ">=": "GE", "&": "BAND",
            "|": "BOR", "~": "BXOR", "<<": "SHL", ">>": "SHR",
        }[op]

    def compile_values(self, values: list[Node], expected: int) -> list[int]:
        if expected <= 0: return []
        out: list[int] = []
        for i, expr in enumerate(values):
            remaining = expected - len(out)
            if remaining <= 0: break
            is_last = i == len(values) - 1
            if is_last and remaining > 1 and isinstance(expr, (Call, Vararg)):
                base = self.compile_expr(expr, results=remaining)
                out.extend(base + j for j in range(remaining))
            else:
                out.append(self.compile_expr(expr))
        while len(out) < expected:
            reg = self.alloc(); self.emit("LOADNIL", reg); out.append(reg)
        return out[:expected]

    def compile_expr(self, expr: Node, results: int = 1) -> int:
        if isinstance(expr, Literal):
            reg = self.alloc()
            if expr.value is None: self.emit("LOADNIL", reg)
            elif expr.value is True: self.emit("LOADBOOL", reg, 1)
            elif expr.value is False: self.emit("LOADBOOL", reg, 0)
            else: self.emit("LOADK", reg, self.owner.constants.add(expr.value))
            return reg
        if isinstance(expr, Name):
            kind, idx = self.resolve_name(expr.name)
            if kind == "local": return idx
            reg = self.alloc()
            self.emit("GETUPVAL" if kind == "up" else "LOADGLOBAL", reg, idx)
            return reg
        if isinstance(expr, Vararg):
            reg = self.alloc(max(results, 1))
            self.emit("VARARG", reg, results)
            return reg
        if isinstance(expr, Unary):
            value = self.compile_expr(expr.value); reg = self.alloc()
            op = {"not": "NOT", "-": "UNM", "#": "LEN", "~": "BNOT"}[expr.op]
            self.emit(op, reg, value); return reg
        if isinstance(expr, Binary):
            if expr.op in ("and", "or"):
                left = self.compile_expr(expr.left); out = self.alloc(); self.emit("MOVE", out, left)
                if expr.op == "and": j = self.emit("JMPIFNOT", out, 0)
                else: j = self.emit("JMPIF", out, 0)
                right = self.compile_expr(expr.right); self.emit("MOVE", out, right)
                self.patch(j, "b", len(self.code) + 1)
                return out
            left = self.compile_expr(expr.left); right = self.compile_expr(expr.right); out = self.alloc()
            self.emit(self.binary_opcode(expr.op), out, left, right); return out
        if isinstance(expr, Index):
            obj = self.compile_expr(expr.obj); key = self.compile_expr(expr.key); out = self.alloc()
            self.emit("GETTABLE", out, obj, key); return out
        if isinstance(expr, Call): return self.compile_call(expr, results)
        if isinstance(expr, Table):
            out = self.alloc(); self.emit("NEWTABLE", out)
            array_index = 1
            for field_index, field in enumerate(expr.fields):
                # As in Lua, only the final array-style field expands a call or vararg.
                if field.kind == "array" and field_index == len(expr.fields) - 1 and isinstance(field.value, (Call, Vararg)):
                    dest = self.alloc()
                    if isinstance(field.value, Call): self.compile_call(field.value, -1, output_base=dest)
                    else: self.emit("VARARG", dest, -1)
                    self.emit("SETLIST", out, array_index, dest)
                    break
                if field.kind == "array":
                    key = self.alloc(); self.emit("LOADK", key, self.owner.constants.add(array_index)); array_index += 1
                else:
                    assert field.key is not None
                    key = self.compile_expr(field.key)
                val = self.compile_expr(field.value)
                self.emit("SETTABLE", out, key, val)
            return out
        if isinstance(expr, Function):
            child = self.compile_function(expr); out = self.alloc(); self.emit("CLOSURE", out, child); return out
        if isinstance(expr, StringInterp):
            pieces: list[int] = []
            for kind, val in expr.parts:
                if kind == "text": pieces.append(self.compile_expr(Literal(val)))
                else:
                    v = self.compile_expr(val)  # type: ignore[arg-type]
                    f = self.alloc(); self.emit("LOADGLOBAL", f, self.owner.constants.add("tostring"))
                    base = self.alloc(2); self.emit("MOVE", base, f); self.emit("MOVE", base + 1, v)
                    self.emit("CALL", base, 1, 1)
                    pieces.append(base)
            if not pieces: return self.compile_expr(Literal(""))
            out = pieces[0]
            for p in pieces[1:]:
                n = self.alloc(); self.emit("CONCAT", n, out, p); out = n
            return out
        if isinstance(expr, IfExpr):
            cond = self.compile_expr(expr.condition); out = self.alloc()
            jf = self.emit("JMPIFNOT", cond, 0)
            yes = self.compile_expr(expr.yes); self.emit("MOVE", out, yes)
            je = self.emit("JMP", 0)
            self.patch(jf, "b", len(self.code) + 1)
            no = self.compile_expr(expr.no); self.emit("MOVE", out, no)
            self.patch(je, "a", len(self.code) + 1)
            return out
        raise CompileError(f"unsupported expression node: {type(expr).__name__}")

    def compile_call(self, expr: Node, results: int = 1, tail: bool = False,
                     output_base: Optional[int] = None) -> int:
        if not isinstance(expr, Call): raise CompileError("internal: expected call expression")
        if expr.method is not None:
            obj = self.compile_expr(expr.func)
            fn = self.alloc(); key = self.alloc(); self.emit("LOADK", key, self.owner.constants.add(expr.method))
            self.emit("GETTABLE", fn, obj, key)
            arg_exprs = list(expr.args)
            arg_regs: list[int] = [obj]
        else:
            fn = self.compile_expr(expr.func)
            arg_exprs = list(expr.args)
            arg_regs = []
        expands = bool(arg_exprs) and isinstance(arg_exprs[-1], (Call, Vararg))
        fixed_exprs = arg_exprs[:-1] if expands else arg_exprs
        for arg_expr in fixed_exprs:
            assert arg_expr is not None
            arg_regs.append(self.compile_expr(arg_expr))
        # Reserve a contiguous function/argument window. When CALL produces
        # multiple fixed results into its own base (e.g. `local iter, state,
        # control = ipairs(items)`), that same window is also the result
        # window. It must be large enough for every result, otherwise the
        # allocator may hand base+2 to the next local and overwrite the third
        # returned value before it is copied. This manifested as iterator
        # state/control corruption (`ipairs` receiving a function as index).
        call_window = len(arg_regs) + (2 if expands else 1)
        if output_base is None and results > 0:
            call_window = max(call_window, results)
        base = self.alloc(call_window)
        self.emit("MOVE", base, fn)
        for i, arg in enumerate(arg_regs, 1): self.emit("MOVE", base + i, arg)
        argc = len(arg_regs)
        if expands:
            last = arg_exprs[-1]
            dynbase = base + len(arg_regs) + 1
            if isinstance(last, Call): self.compile_call(last, -1, output_base=dynbase)
            else: self.emit("VARARG", dynbase, -1)
            argc = -1
        if tail:
            if expands: raise CompileError("expanded final args in tail-call syntax are not implemented")
            self.emit("TAILCALL", base, argc); return base
        out_base = output_base if output_base is not None else 0
        self.emit("CALL", base, argc, results, out_base)
        return out_base if out_base else base

    def prepare_lvalue(self, target: Node) -> tuple[str, Any, Any]:
        if isinstance(target, Name):
            kind, idx = self.resolve_name(target.name)
            return (kind, idx, None)
        if isinstance(target, Index):
            obj = self.compile_expr(target.obj); key = self.compile_expr(target.key)
            return ("index", obj, key)
        raise CompileError(f"invalid assignment target: {type(target).__name__}")

    def read_target(self, target: tuple[str, Any, Any]) -> int:
        kind, a, b = target
        if kind == "local": return a
        if kind == "up":
            out = self.alloc(); self.emit("GETUPVAL", out, a); return out
        if kind == "global":
            out = self.alloc(); self.emit("LOADGLOBAL", out, a); return out
        if kind == "index":
            out = self.alloc(); self.emit("GETTABLE", out, a, b); return out
        raise CompileError("invalid target kind")

    def store_target(self, target: tuple[str, Any, Any], value: int) -> None:
        kind, a, b = target
        if kind == "local": self.emit("MOVE", a, value)
        elif kind == "up": self.emit("SETUPVAL", a, value)
        elif kind == "global": self.emit("STOREGLOBAL", a, value)
        elif kind == "index": self.emit("SETTABLE", a, b, value)
        else: raise CompileError("invalid target kind")
